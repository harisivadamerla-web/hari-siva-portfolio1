# Hari Siva Damerla — portfolio (reference-matched version)

This version uses the approved orange-and-black portfolio visual as the exact desktop hero artwork, so the first screen matches the reference composition much more closely. The hero navigation and CTA areas are clickable overlays on desktop. The rest of the site is built as responsive HTML/CSS sections.

## Deploy
1. Extract this ZIP.
2. Push the contents of this folder to a GitHub repository.
3. Import the repository at https://vercel.com/new.
4. Framework preset: Other; Build Command: blank; Output Directory: `.`.
5. Deploy.

## Important edits before publishing
- Replace `YOUR.EMAIL@example.com` in `index.html`.
- Replace the LinkedIn and GitHub URLs with your real profiles.
- Add your PDF resume at `assets/resume.pdf` (the hero's resume buttons link to this file).
- Update dates, role descriptions, achievements and project outcomes with verified resume details.
- The small screen uses a simplified responsive content layout; the desktop hero artwork is kept intact to preserve the exact reference design.

Files:
- `index.html` — page content
- `styles.css` — styling and responsive layout
- `script.js` — smooth scrolling
- `assets/hero-reference.png` — approved hero design artwork
- `assets/hari-original-photo.jpg` — original uploaded portrait for future avatar refinements
